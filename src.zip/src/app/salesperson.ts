export class salesperson {

  

  constructor(
    
      public firstname : string,
      public lastname : string,
      public email : string,
      public salary : number,
      public salesVolume : string 
  ){}
}