import { Component, OnInit } from '@angular/core';
import { salesperson } from '../salesperson';

@Component({
  selector: 'app-sales-person-list',
  templateUrl: './sales-person-list.component.html',
  styleUrls: ['./sales-person-list.component.css']
})
export class SalesPersonListComponent implements OnInit {

  name : String = "Prajjwal";
  s1: salesperson = new salesperson("Prajjwal","Chauhan","pchauhan@gmail.com",34000,"200");

salesList :salesperson[] = [
                              this.s1,
                              new salesperson("Prajjwal","Chauhan","pchauhan@gmail.com",30000,"300"),
                              new salesperson("Akash ","kumar","ak@gmail.com",20000,"300"),
                              new salesperson("Mihir","Mehta","mm@gmail.com",10000,"400"),
                              new salesperson("Shiva","Rai","shivar@gmail.com",50000,"500"),
                              new salesperson("Saroj","singh","ss@gmail.com",5000,"900")
                          ]
formModel : salesperson=new salesperson("","","",0,"");


  constructor() { }

  ngOnInit(): void {

    // console.log(this.formModel)
    // this.salesList.push(this.formModel);
  }
  onSubmit()
  {
    this.salesList.push(this.formModel);
  }

}